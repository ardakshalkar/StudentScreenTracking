export interface Identity {server:string; name:string; studentId:string; code:string}
export interface Joined {token:string; session:string; student:string; recording:boolean; interval:number; key:string; email?:string|null}
export const identityKey = (identity:Identity) => JSON.stringify(identity);
export async function loadConfig():Promise<Partial<Identity>> {
  return (await chrome.storage.local.get('identity')).identity || {};
}
export async function saveConfig(identity:Identity) { await chrome.storage.local.set({identity}); }
export function serverURL(value:string):string {
  const url = new URL(value);
  if (!['https:', 'http:'].includes(url.protocol) || url.username || url.password || url.pathname !== '/' || url.search || url.hash) throw Error('Use a server origin, such as https://classroom.example.edu');
  if (url.protocol !== 'https:' && !['localhost', '127.0.0.1', '[::1]'].includes(url.hostname)) throw Error('Remote classrooms require HTTPS. HTTP is allowed only on localhost.');
  return url.origin;
}
