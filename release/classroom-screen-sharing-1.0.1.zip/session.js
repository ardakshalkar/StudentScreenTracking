// src/config.ts
var identityKey = (identity2) => JSON.stringify(identity2);
async function loadConfig() {
  return (await chrome.storage.local.get("identity")).identity || {};
}
async function saveConfig(identity2) {
  await chrome.storage.local.set({ identity: identity2 });
}
function serverURL(value) {
  const url = new URL(value);
  if (!["https:", "http:"].includes(url.protocol) || url.username || url.password || url.pathname !== "/" || url.search || url.hash) throw Error("Use a server origin, such as https://classroom.example.edu");
  if (url.protocol !== "https:" && !["localhost", "127.0.0.1", "[::1]"].includes(url.hostname)) throw Error("Remote classrooms require HTTPS. HTTP is allowed only on localhost.");
  return url.origin;
}

// src/auth.ts
async function joinClassroom(identity2, google) {
  await saveConfig(identity2);
  const saved = (await chrome.storage.local.get("joined")).joined;
  if (!google && saved?.key === identityKey(identity2)) {
    try {
      if (JSON.parse(atob(saved.token.split(".")[0].replace(/-/g, "+").replace(/_/g, "/"))).exp > Date.now() / 1e3 + 60) return saved;
    } catch {
    }
  }
  const response = await fetch(identity2.server + "/api/join", { method: "POST", headers: { "Content-Type": "application/json", ...google ? { Authorization: "Bearer " + google.token } : {} }, body: JSON.stringify({ name: identity2.name, student_id: identity2.studentId, code: identity2.code }), signal: AbortSignal.timeout(1e4) });
  const body = await response.json();
  if (!response.ok) throw Error(typeof body.detail === "string" ? body.detail : "Check your name, ID, and eight-character classroom code.");
  const joined2 = { ...body, key: identityKey(identity2) };
  await chrome.storage.local.set({ joined: joined2 });
  return joined2;
}

// src/capture.ts
var pendingPicker;
function cancelPicker() {
  if (pendingPicker !== void 0) chrome.desktopCapture.cancelChooseDesktopMedia(pendingPicker);
  pendingPicker = void 0;
}
function chooseScreen() {
  return new Promise((resolve, reject) => {
    pendingPicker = chrome.desktopCapture.chooseDesktopMedia(["screen", "window"], async (id) => {
      pendingPicker = void 0;
      if (chrome.runtime.lastError) return reject(Error(chrome.runtime.lastError.message));
      if (!id) return reject(Error("Screen selection cancelled. Nothing is being shared."));
      try {
        const stream2 = await navigator.mediaDevices.getUserMedia({ audio: false, video: { mandatory: {
          chromeMediaSource: "desktop",
          chromeMediaSourceId: id,
          maxWidth: 1920,
          maxHeight: 1920,
          maxFrameRate: 5
        } } });
        resolve(stream2);
      } catch (error) {
        reject(error);
      }
    });
  });
}

// src/quality.ts
var qualities = {
  overview: { width: 640, interval: 2500, quality: 0.68, maxBytes: 6e4 },
  focused: { width: 1600, interval: 333, quality: 0.9, maxBytes: 65e4 }
};

// src/compression.ts
var Compressor = class {
  constructor(canvas) {
    this.canvas = canvas;
    this.probe.width = 96;
    this.probe.height = 54;
  }
  previous;
  previousMode;
  probe = document.createElement("canvas");
  reset() {
    this.previous = void 0;
  }
  async frame(video2, mode2) {
    if (!video2.videoWidth || !video2.videoHeight || video2.readyState < 2) return null;
    const probe = this.probe.getContext("2d", { willReadFrequently: true });
    probe.drawImage(video2, 0, 0, 96, 54);
    const pixels = probe.getImageData(0, 0, 96, 54).data;
    let changed = !this.previous || this.previousMode !== mode2;
    if (!changed) for (let i = 0; i < pixels.length; i += 4) {
      if (Math.abs(pixels[i] - this.previous[i]) + Math.abs(pixels[i + 1] - this.previous[i + 1]) + Math.abs(pixels[i + 2] - this.previous[i + 2]) > 12) {
        changed = true;
        break;
      }
    }
    if (!changed) return null;
    const q = qualities[mode2];
    const scale = Math.min(1, q.width / video2.videoWidth, 1920 / video2.videoHeight);
    this.canvas.width = Math.round(video2.videoWidth * scale);
    this.canvas.height = Math.round(video2.videoHeight * scale);
    this.canvas.getContext("2d").drawImage(video2, 0, 0, this.canvas.width, this.canvas.height);
    const encode = (quality) => new Promise((resolve) => this.canvas.toBlob(resolve, "image/webp", quality));
    let blob = await encode(q.quality);
    if (mode2 === "overview" && blob && blob.size > q.maxBytes) blob = await encode(0.48);
    if (!blob || blob.size > 95e4) return null;
    this.previous = pixels;
    this.previousMode = mode2;
    return blob;
  }
};

// src/connection.ts
var Connection = class {
  constructor(server, token, onMessage, onState, onFatal, captureHealthy) {
    this.server = server;
    this.token = token;
    this.onMessage = onMessage;
    this.onState = onState;
    this.onFatal = onFatal;
    this.captureHealthy = captureHealthy;
  }
  ws;
  retry;
  heartbeat;
  stopped = false;
  attempts = 0;
  pendingAt = null;
  ready = false;
  lastServerAt = Date.now();
  start() {
    this.connect();
  }
  connect() {
    if (this.stopped) return;
    this.onState("Connecting\u2026");
    const ws = this.ws = new WebSocket(this.server.replace(/^http/, "ws") + "/api/ws/student");
    const handshake = setTimeout(() => ws.close(), 1e4);
    ws.onopen = () => ws.send(JSON.stringify({ token: this.token }));
    ws.onmessage = (event) => {
      let body;
      try {
        body = JSON.parse(event.data);
      } catch {
        ws.close();
        return;
      }
      this.lastServerAt = Date.now();
      if (body.type === "ready") {
        clearTimeout(handshake);
        this.attempts = 0;
        this.pendingAt = null;
        this.ready = true;
        this.onState("Sharing \u2014 connected");
      }
      if (body.type === "ack") this.pendingAt = null;
      if (body.type === "session_ended") {
        this.onFatal("Classroom ended. Capture stopped.");
        return;
      }
      this.onMessage(body);
    };
    ws.onclose = (event) => {
      clearTimeout(handshake);
      this.ready = false;
      this.pendingAt = null;
      if (this.stopped) return;
      if ([4004, 4009, 4400, 4401, 4403].includes(event.code)) {
        this.onFatal(event.code === 4004 ? "Classroom ended. Capture stopped." : "Sharing authorization ended or connection replaced. Join again.");
        return;
      }
      this.onState("Sharing paused \u2014 reconnecting; no frames are queued");
      const delay = Math.min(15e3, 500 * 2 ** Math.min(this.attempts++, 5)) + Math.random() * 400;
      this.retry = setTimeout(() => this.connect(), delay);
    };
    ws.onerror = () => ws.close();
    if (!this.heartbeat) this.heartbeat = setInterval(() => {
      if (this.stopped) return;
      if (Date.now() - this.lastServerAt > 3e4) {
        this.onFatal("Server unavailable for 30 seconds. Capture stopped. Start Sharing again after reconnecting.");
        return;
      }
      if (this.pendingAt !== null && Date.now() - this.pendingAt > 1e4) this.ws?.close();
      if (this.ws?.readyState === WebSocket.OPEN && this.ready) this.ws.send(JSON.stringify({ type: "heartbeat", captureHealthy: this.captureHealthy() }));
    }, 5e3);
  }
  canSend() {
    return this.ready && this.ws?.readyState === WebSocket.OPEN && this.pendingAt === null && this.ws.bufferedAmount < 1e5;
  }
  async send(blob) {
    const data = await blob.arrayBuffer();
    if (!this.canSend() || this.stopped) return false;
    this.pendingAt = Date.now();
    this.ws.send(data);
    return true;
  }
  stop() {
    this.stopped = true;
    this.ready = false;
    clearTimeout(this.retry);
    clearInterval(this.heartbeat);
    if (this.ws?.readyState === WebSocket.OPEN) this.ws.send(JSON.stringify({ type: "stop" }));
    this.ws?.close(1e3);
    this.ws = void 0;
  }
};

// src/google-auth.ts
async function policy(server) {
  const response = await fetch(server + "/api/student-auth/config", { signal: AbortSignal.timeout(1e4) });
  if (!response.ok) throw Error("Cannot load the classroom sign-in settings.");
  return response.json();
}
function randomValue() {
  return Array.from(crypto.getRandomValues(new Uint8Array(32)), (v) => v.toString(16).padStart(2, "0")).join("");
}
async function challenge(verifier) {
  const digest = new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(verifier)));
  return btoa(String.fromCharCode(...digest)).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}
async function googleSignIn(server, code) {
  const verifier = randomValue(), state = randomValue();
  const response = await fetch(server + "/api/student-auth/start", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ code, extension_id: chrome.runtime.id, challenge: await challenge(verifier), client_state: state }),
    signal: AbortSignal.timeout(1e4)
  });
  const body = await response.json();
  if (!response.ok) throw Error(typeof body.detail === "string" ? body.detail : "Google sign-in could not start.");
  const destination = new URL(body.url);
  if (destination.origin !== "https://accounts.google.com") throw Error("Unexpected Google sign-in provider.");
  const returned = await chrome.identity.launchWebAuthFlow({ url: destination.href, interactive: true });
  if (!returned) throw Error("Google sign-in was cancelled.");
  const url = new URL(returned), expected = new URL(chrome.identity.getRedirectURL("student-login"));
  const result = new URLSearchParams(url.hash.slice(1));
  if (url.origin !== expected.origin || url.pathname !== expected.pathname || result.get("client_state") !== state) throw Error("Google sign-in state mismatch. Please try again.");
  if (result.has("error")) throw Error(result.get("error"));
  const exchanged = await fetch(server + "/api/student-auth/exchange", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ grant: result.get("grant"), verifier }),
    signal: AbortSignal.timeout(1e4)
  });
  const identity2 = await exchanged.json();
  if (!exchanged.ok) throw Error(typeof identity2.detail === "string" ? identity2.detail : "Google sign-in could not be completed.");
  return identity2;
}

// src/session.ts
var $ = (id) => document.getElementById(id);
var status = $("status");
var start = $("start");
var stop = $("stop");
var video = $("source");
var compressor = new Compressor($("canvas"));
var identity;
var joined;
var stream;
var connection;
var mode = "overview";
var timer;
var busy = false;
var healthyAt = 0;
var previousVideoTime = -1;
var active = false;
var generation = 0;
function setStatus(value) {
  status.textContent = value;
  document.title = active ? "\u25CF Sharing \u2014 Classroom" : "Classroom sharing controls";
}
function recording(body) {
  if (typeof body.recording === "boolean") $("recording").textContent = body.recording ? `RECORDING ON \xB7 a changed screenshot every ${body.interval} seconds` : "Recording off \xB7 live viewing only";
}
function setMode(value) {
  mode = value;
  compressor.reset();
  $("quality").textContent = value === "focused" ? "Teacher is viewing your screen \xB7 1600px \xB7 3 fps" : "Overview \xB7 640px \xB7 every 2.5 seconds";
}
function message(body) {
  recording(body);
  if (body.mode) setMode(body.mode);
  if (body.type === "ready") compressor.reset();
}
function end(reason = "Not sharing \u2014 capture stopped") {
  generation++;
  active = false;
  clearTimeout(timer);
  cancelPicker();
  connection?.stop();
  connection = void 0;
  stream?.getTracks().forEach((track) => track.stop());
  stream = void 0;
  video.srcObject = null;
  compressor.reset();
  start.disabled = !joined;
  stop.disabled = true;
  $("connect").disabled = false;
  setStatus(reason);
  void chrome.action.setBadgeText({ text: "" });
}
function enteredIdentity() {
  return { server: serverURL($("server").value.trim()), name: $("name").value.trim(), studentId: $("studentId").value.trim(), code: $("code").value.trim().toUpperCase() };
}
function didJoin() {
  recording({ type: "recording", ...joined });
  start.disabled = false;
  $("account").textContent = joined?.email ? `Signed in as ${joined.email}` : "Joined using classroom code and student ID.";
  setStatus("Joined. Click Start Sharing to select a screen or window.");
}
async function tick(owner) {
  if (!active || owner !== generation) return;
  const started = Date.now();
  if (video.currentTime !== previousVideoTime && video.readyState >= 2 && stream?.getVideoTracks()[0]?.readyState === "live") {
    healthyAt = Date.now();
    previousVideoTime = video.currentTime;
  }
  const sender = connection;
  if (sender?.canSend() && Date.now() - healthyAt < 1e4) {
    try {
      const blob = await compressor.frame(video, mode);
      if (active && owner === generation && blob && !await sender.send(blob)) compressor.reset();
    } catch (error) {
      $("detail").textContent = String(error);
    }
  }
  if (active && owner === generation) timer = setTimeout(() => void tick(owner), Math.max(50, qualities[mode].interval - (Date.now() - started)));
}
for (const [key, value] of Object.entries(await loadConfig())) {
  const element = document.getElementById(key);
  if (element) element.value = value;
}
if (!$("server").value) $("server").value = "http://localhost:5173";
$("join").addEventListener("submit", async (event) => {
  event.preventDefault();
  if (active || busy) return;
  const button = $("connect");
  button.disabled = true;
  start.disabled = true;
  joined = void 0;
  try {
    identity = enteredIdentity();
    const allowed = await chrome.permissions.request({ origins: [identity.server + "/*"] });
    if (!allowed) throw Error("Server access was declined. Nothing is being shared.");
    const settings = await policy(identity.server);
    $("google").hidden = settings.mode !== "google";
    $("manualIdentity").hidden = settings.mode === "google";
    if (settings.mode === "google") {
      $("account").textContent = "Allowed Google email domains: " + settings.allowed_domains.join(", ");
      setStatus("Click Sign in with Google & join to verify your school account.");
    } else {
      if (!identity.name || !identity.studentId) throw Error("Enter your name and student ID for this code-only classroom.");
      joined = await joinClassroom(identity);
      didJoin();
    }
  } catch (error) {
    setStatus(error instanceof Error ? error.message : String(error));
  } finally {
    button.disabled = false;
  }
});
$("google").addEventListener("click", async () => {
  if (active || busy) return;
  busy = true;
  start.disabled = true;
  joined = void 0;
  const button = $("google");
  button.disabled = true;
  $("connect").disabled = true;
  try {
    identity = enteredIdentity();
    if (!/^[A-Z2-9]{8}$/.test(identity.code)) throw Error("Enter the eight-character classroom code.");
    const account = await googleSignIn(identity.server, identity.code);
    identity = { ...identity, name: account.name, studentId: account.email };
    $("name").value = identity.name;
    $("studentId").value = identity.studentId;
    joined = await joinClassroom(identity, account);
    didJoin();
  } catch (error) {
    setStatus(error instanceof Error ? error.message : String(error));
  } finally {
    busy = false;
    button.disabled = false;
    $("connect").disabled = false;
  }
});
start.addEventListener("click", async () => {
  if (!joined || active || busy) return;
  if (!$("consent").checked) {
    setStatus("Read the sharing disclosure and check the acknowledgement before selecting a screen.");
    $("consent").focus();
    return;
  }
  busy = true;
  start.disabled = true;
  $("connect").disabled = true;
  const owner = ++generation;
  try {
    const selected = await chooseScreen();
    if (owner !== generation) {
      selected.getTracks().forEach((track) => track.stop());
      return;
    }
    stream = selected;
    stream.getVideoTracks()[0].onended = () => end("Chrome ended screen sharing. Capture stopped.");
    video.srcObject = stream;
    await video.play();
    active = true;
    healthyAt = Date.now();
    previousVideoTime = -1;
    setMode("overview");
    stop.disabled = false;
    void chrome.action.setBadgeBackgroundColor({ color: "#c33c45" });
    void chrome.action.setBadgeText({ text: "LIVE" });
    connection = new Connection(identity.server, joined.token, message, setStatus, (reason) => end(reason), () => active && Date.now() - healthyAt < 1e4);
    connection.start();
    void tick(owner);
  } catch (error) {
    end(error instanceof Error ? error.message : String(error));
  } finally {
    busy = false;
  }
});
stop.addEventListener("click", () => end());
chrome.runtime.onMessage.addListener((body, sender, reply) => {
  if (sender.id !== chrome.runtime.id || body.target !== "capture") return;
  if (body.type === "stop") end();
  reply({ status: status.textContent });
});
window.addEventListener("pagehide", () => end());
//# sourceMappingURL=session.js.map
